import { StartRatingPipe } from './start-rating.pipe';

describe('StartRatingPipe', () => {
  it('create an instance', () => {
    const pipe = new StartRatingPipe();
    expect(pipe).toBeTruthy();
  });
});
